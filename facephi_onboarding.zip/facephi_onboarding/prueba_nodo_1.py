import base64
import requests

# 1. PON AQUÍ LA URL DE TU WEBHOOK DE N8N
# (La que te sale cuando le das a "Listen for test event")
N8N_WEBHOOK_URL = "http://localhost:5678/webhook-test/recibir-dni"

def convertir_a_base64(ruta_imagen):
    """Lee la foto del disco duro y la convierte a texto Base64."""
    with open(ruta_imagen, "rb") as img_file:
        b64_string = base64.b64encode(img_file.read()).decode('utf-8')
        # Le añadimos la cabecera estándar de imagen para simular una web
        return f"data:image/jpeg;base64,{b64_string}"

print("Convirtiendo imágenes a Base64...")

# 2. ASEGÚRATE DE QUE ESTOS SON LOS NOMBRES DE TUS FOTOS DE PRUEBA
# (Deben estar en la misma carpeta que este script)
ruta_frontal = "dni_front_especimen.jpg"
ruta_trasera = "dni_back_especimen.jpg"

try:
    front_b64 = convertir_a_base64(ruta_frontal)
    back_b64 = convertir_a_base64(ruta_trasera)
except FileNotFoundError as e:
    print(f"❌ ERROR: No encuentro la imagen. Asegúrate de que '{ruta_frontal}' y '{ruta_trasera}' están en esta carpeta.")
    exit()

# 3. EMPAQUETAMOS LOS DATOS EN UN JSON
payload = {
    "front_image": front_b64,
    "back_image": back_b64
}

print(f"Disparando datos a n8n en: {N8N_WEBHOOK_URL} ...")

# 4. ENVIAMOS EL PAQUETE AL WEBHOOK
try:
    respuesta = requests.post(N8N_WEBHOOK_URL, json=payload)
    print(f"✅ ¡Éxito! Código de respuesta de n8n: {respuesta.status_code}")
    if respuesta.status_code == 200:
        print("¡Ve a mirar n8n, ya debería haber capturado las imágenes!")
    else:
        print(f"Mensaje del servidor: {respuesta.text}")
except requests.exceptions.ConnectionError:
    print("❌ ERROR: No me puedo conectar a n8n. ¿Estás seguro de que la URL es correcta y n8n está encendido?")