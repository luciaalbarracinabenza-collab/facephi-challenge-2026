import streamlit as st
import base64
import requests

st.set_page_config(page_title="HealthGuard | Onboarding", page_icon="🏥", layout="wide")

# URL n8n
N8N_WEBHOOK_URL = "http://localhost:5678/webhook-test/recibir-dni"

def convertir_a_base64(imagen_bytes):
    b64_string = base64.b64encode(imagen_bytes).decode('utf-8')
    return f"data:image/jpeg;base64,{b64_string}"
st.title("🏥 HealthGuard: Portal del Paciente")
st.markdown("Bienvenido al sistema seguro de admisión. Por favor, verifique su identidad para acceder a la consulta de telemedicina.")
st.divider()
tab1, tab2 = st.tabs(["📸 Usar Cámara Web", "📁 Subir Archivos"])
front_data = None
back_data = None
selfie_data = None
st.subheader("1. Prueba de Vida (Selfie)")
st.info("Mire a la cámara para verificar que es usted el titular del documento.")
col1, col_cam, col2 = st.columns([1, 2, 1])

with col_cam:
    foto_selfie = st.camera_input("Capturar Selfie", key="cam_selfie")
if foto_selfie:
    selfie_data = foto_selfie.getvalue()   
st.divider()
st.subheader("2. Documento de Identidad (DNI)")
col_up1, col_up2 = st.columns(2)
with col_up1:
    archivo_frontal = st.file_uploader("Subir Frontal (JPG/PNG)", type=['jpg', 'jpeg', 'png'])
    if archivo_frontal: 
        front_data = archivo_frontal.read()
            
with col_up2:
    archivo_trasero = st.file_uploader("Subir Reverso (JPG/PNG)", type=['jpg', 'jpeg', 'png'])
    if archivo_trasero: 
        back_data = archivo_trasero.read()

st.divider()
if st.button("🔐 Iniciar Análisis Forense de Identidad", type="primary", use_container_width=True):
    if front_data and back_data:
        barra = st.progress(0, text="Iniciando conexión segura con el hospital...")
        payload = {
            "front_image": convertir_a_base64(front_data),
            "back_image": convertir_a_base64(back_data),
            "selfie_image": convertir_a_base64(selfie_data) 
        }
        
        barra.progress(40, text="Enviando a n8n y ejecutando IA")

        try:
            respuesta = requests.post(N8N_WEBHOOK_URL, json=payload)
            datos_crudos = respuesta.json()
            barra.progress(100, text="Análisis completado.")
            if isinstance(datos_crudos, list) and len(datos_crudos) > 0:
                datos = datos_crudos[0] 
            else:
                datos = datos_crudos
                                                                                                                                                                   #st.json(datos)
            riesgo = datos.get("fraud_risk_level", "UNKNOWN")
        
            st.header("📊 Resultados de Auditoría")
            kpi1, kpi2, kpi3, kpi4,kpi5= st.columns(5)
            scores = datos.get("scores", {})
            kpi1.metric("Nivel de Riesgo", riesgo)
            kpi2.metric("Score MRZ", scores.get("mrz", 0))
            kpi3.metric("Score Cruzado", scores.get("cross_validation", 0))
            kpi4.metric("Score Temporal", scores.get("temporal_logic", 0))
            kpi5.metric("Score Forense", scores.get("forensics", 0))

            
            if riesgo == "LOW":
                st.success("✅ **IDENTIDAD CONFIRMADA.** El documento ha superado las pruebas antifraude.")
                st.balloons()
                st.markdown("### 👨‍⚕️ [Entrar a la Sala de Espera de Telemedicina](#)")
                url_meet = "https://meet.google.com/bga-smrz-gxz" 
                st.markdown(f"""
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="{url_meet}" target="_blank" style="background-color: #2e7d32; color: white; padding: 15px 25px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 20px;">
                            ENTRAR A LA CONSULTA AHORA
                        </a>
                    </div>
                """, unsafe_allow_html=True)
            elif riesgo == "MEDIUM":
                st.warning("⚠️ **VERIFICACIÓN EN CURSO.**")
                st.info("Hemos detectado algunos datos que requieren una revisión manual. Un médico validará su acceso en unos minutos.")
                st.write("Recibirá un correo electrónico con el enlace de acceso en cuanto se complete la validación.")

            else: 
                st.error("🚨 **ALERTA: ACCESO DENEGADO.**")
                st.error("Se han detectado anomalías de seguridad graves. Por favor, acuda a recepción.")
                with st.expander("Ver informe pericial detallado"):
                    st.write("**Inconsistencias detectadas:**")
                    for fallo in datos.get("cross_validation", {}).get("inconsistencies", []):
                        st.warning(f"⚠️ {fallo}")
                    for fallo in datos.get("temporal_logic", {}).get("issues", []):
                        st.warning(f"🕒 {fallo[1]}")
        except Exception as e:
            st.error("Error de comunicación con el motor de IA.")
            st.write(e)
    else:
        st.warning("⚠️ Faltan imágenes. Debe proporcionar ambas caras del documento.")