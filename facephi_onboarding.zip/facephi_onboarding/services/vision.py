import re
from doctr.io import DocumentFile
from doctr.models import ocr_predictor
import re
from services.funciones_matematicas import validate_td1, looks_like_yymmdd



CLI_TEMPLATES = {
    "RESOLUCION_BASE": {"width": 1000, "height": 700},
    "TD1": { # Formato Tarjeta (DNI)
        "ESP": {
            "descripcion": "DNI Español v4.0",
            "ocr_map": {
                "nombre": {"top": 120, "left": 300, "width": 400, "height": 50},
                "apellidos": {"top": 180, "left": 300, "width": 400, "height": 80},
                "soporte": {"top": 50, "left": 620, "width": 150, "height": 40},
                "nif_frontal": {"top": 350, "left": 300, "width": 200, "height": 50}
            },
            "validaciones_criticas": ["nif_check", "idesp_check"]
        },
        "DEFAULT": {
            "descripcion": "ID Card Genérica",
            "ocr_map": {
                "nombre": {"top": 100, "left": 250, "width": 500, "height": 60},
                "numero_doc": {"top": 40, "left": 550, "width": 200, "height": 50}
            }
        }
    },
    "TD2": { # Formato Intermedio (Residencias/Rumanía)
        "ROU": {
            "descripcion": "ID Rumanía",
            "ocr_map": {
                "nombre": {"top": 150, "left": 100, "width": 600, "height": 100},
                "expiry": {"top": 500, "left": 400, "width": 200, "height": 50}
            }
        }
    },
    "TD3": { # Formato Pasaporte
        "DEFAULT": {
            "descripcion": "Pasaporte Estándar ICAO",
            "ocr_map": {
                "nombre_completo": {"top": 400, "left": 100, "width": 800, "height": 120},
                "pasaporte_no": {"top": 50, "left": 700, "width": 250, "height": 60}
            }
        }
    }
}
def detectar_formato(lineas_mrz):
    num_lineas = len(lineas_mrz)
    caracteres = len(lineas_mrz[0])

    if num_lineas == 3 and caracteres == 30:
        return "TD1"
    elif num_lineas == 2 and caracteres == 44:
        return "TD3"
    elif num_lineas == 2 and caracteres == 36:
        return "TD2"
    else:
        return "UNKNOWN"
def selector_mapa(lineas_mrz):
    formato = detectar_formato(lineas_mrz)

    if formato == "UNKNOWN":
        return None, "Error: Estructura de MRZ no reconocida"
    pais = lineas_mrz[0][2:5].replace('<', '')
    mapa_formato = CLI_TEMPLATES.get(formato, {})
    plantilla = mapa_formato.get(pais, mapa_formato.get("DEFAULT", {}))
    return {
        "formato": formato,
        "pais": pais,
        "config": plantilla
    }, f"Éxito: {plantilla.get('descripcion', 'Formato genérico')}"
# Motor extracción MRZ (TD1) desde OCR (DocTR)
_LT_ALIASES = {"<":"<","«":"<","‹":"<","＜":"<","〈":"<","《":"<","_":"<"}

def _map_char(ch: str) -> str:
    return _LT_ALIASES.get(ch, ch)

def normalize_mrz_text(s: str) -> str:
    s = s.upper().replace(" ", "<")
    s = "".join(_map_char(c) for c in s)
    s = re.sub(r"[^A-Z0-9<]", "", s)
    return s

def doctr_lines(result, min_conf: float = 0.5):
    lines = []
    for page in result.pages:
        for block in page.blocks:
            for line in block.lines:
                words = [w.value for w in line.words if w.confidence >= min_conf]
                if words:
                    lines.append(" ".join(words))
    return lines

def _fix30(s: str) -> str:
    s = normalize_mrz_text(s)
    if len(s) < 30:
        s = s + "<" * (30 - len(s))
    return s[:30]

def extract_best_td1_from_doctr(result, min_conf: float = 0.5):
    raw = doctr_lines(result, min_conf=min_conf)
    normalized = []
    for line in raw:
        n = normalize_mrz_text(line)
        if n and (20 <= len(n) <= 80) and (n.count("<") >= 2 or len(n) >= 25):
            normalized.append(n)

    fixed = [_fix30(x) for x in normalized]

    best = None
    for i in range(len(fixed) - 2):
        triple = [fixed[i], fixed[i+1], fixed[i+2]]
        rep = validate_td1(triple)

        # scoring simple: preferir menos errores y más '<'
        lt_bonus = sum(l.count("<") for l in triple) * 0.2
        score = (1000 if rep["ok"] else 0) + lt_bonus - 50 * len(rep["issues"])

        cand = {
            "score": score,
            "lines": triple,
            "ok": rep["ok"],
            "issues": rep["issues"]
        }

        if best is None or cand["score"] > best["score"]:
            best = cand

    return best
def calcular_entropia_doctr(result, min_conf=0.5):
    """
    Recibe el resultado crudo de DocTR y calcula la confianza media (entropía)
    sin modificar ni extraer el texto.
    """
    lista_confianzas = []
    for page in result.pages:
        for block in page.blocks:
            for line in block.lines:
                for w in line.words:
                    if w.confidence >= min_conf:
                        lista_confianzas.append(w.confidence)

    if not lista_confianzas:
        return 0.0
    entropia_media = sum(lista_confianzas) / len(lista_confianzas)
    return entropia_media

def extract_fields_from_ocr(result):
    raw_lines = doctr_lines(result)
    full_text = " ".join(raw_lines).upper()

    ocr_data = {
        "document_number": None,
        "idesp_frontal": None,
        "birth_date": None,
        "expiry_date": None,
        "full_text": full_text
    }

    # DNI típico: 8 dígitos + letra
    doc_match = re.findall(r"\d{8}[A-Z]", full_text)
    if doc_match:
        ocr_data["document_number"] = doc_match[0]
    # IDESP
    idesp_match = re.findall(r"\b[A-Z]{2,3}\d{6,7}\b", full_text)
    if idesp_match:
        ocr_data["idesp_frontal"] = idesp_match[0]

    # Fechas YYMMDD (filtradas)
    date_matches = re.findall(r"\d{6}", full_text)

    bd = date_matches[0] if len(date_matches) >= 1 else None
    ed = date_matches[1] if len(date_matches) >= 2 else None

    ocr_data["birth_date"]  = bd if looks_like_yymmdd(bd) else None
    ocr_data["expiry_date"] = ed if looks_like_yymmdd(ed) else None


    return ocr_data

#Extraer campos desde MRZ válida
def extractor_mrz_universal(lineas_mrz, formato, pais=""):
    """
    Extrae los datos de la MRZ adaptando las posiciones según el formato ICAO.
    Maneja la excepción del DNI español donde el IDESP ocupa el lugar del Document Number.
    """
    datos = {}

    if formato == "TD1": # DNI (3 líneas x 30 caracteres)
        l1, l2, l3 = lineas_mrz
        # Excepción para España: El NIF va desplazado y el IDESP ocupa el inicio
        if pais == "ESP":
            datos["idesp"]           = l1[5:14].replace("<", "")
            datos["document_number"] = l1[15:25].replace("<", "")
        else:
            datos["idesp"]           = None
            datos["document_number"] = l1[5:14].replace("<", "") 
            
        datos["birth_date"]      = l2[0:6]
        datos["expiry_date"]     = l2[8:14]
        datos["name_line"]       = l3.replace("<", " ").strip()

    elif formato == "TD3": # Pasaporte (2 líneas x 44 caracteres)
        l1, l2 = lineas_mrz
        datos["name_line"]       = l1[5:44].replace("<", " ").strip()
        datos["document_number"] = l2[0:9].replace("<", "")
        datos["birth_date"]      = l2[13:19]
        datos["expiry_date"]     = l2[21:27]
        datos["idesp"]           = None # Los pasaportes no cruzan IDESP

    elif formato == "TD2": # Cédulas grandes / Residencias (2 x 36)
        l1, l2 = lineas_mrz
        datos["name_line"]       = l1[5:36].replace("<", " ").strip()
        datos["document_number"] = l2[0:9].replace("<", "")
        datos["birth_date"]      = l2[13:19]
        datos["expiry_date"]     = l2[21:27]
        datos["idesp"]           = None

    return datos
