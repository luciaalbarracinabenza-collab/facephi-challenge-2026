import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
import torch
import torch.nn as nn
import torchvision.transforms as transforms
from deepface import DeepFace

def validar_biometria_facial(ruta_dni, ruta_selfie):
    """
    Compara el rostro del DNI con el selfie del paciente en vivo.
    """
    try:
        resultado = DeepFace.verify(
            img1_path=ruta_dni, 
            img2_path=ruta_selfie,
            model_name="VGG-Face",
            detector_backend="opencv",
            enforce_detection=True # Falla si no encuentra cara
        )
        
        identico = resultado['verified']
        distancia = resultado['distance']
        
        if identico:
            return True, f"Identidad confirmada. El selfie coincide con el DNI (Dist: {distancia:.2f})."
        else:
            return False, f"SUPLANTACIÓN DE IDENTIDAD: El rostro no coincide (Dist: {distancia:.2f})."
            
    except Exception as e:
        return False, f"ERROR BIOMÉTRICO: No se detectó un rostro claro. Pida repetir la foto."

def detectar_ataque_pantalla(ruta_imagen):
    UMBRAL_BRILLO = 260
    MAX_PICOS_PERMITIDOS = 1000
    img = cv2.imread(ruta_imagen, 0)
    if img is None:
        return False, "Error: No se pudo leer la imagen para el análisis físico."
    f = np.fft.fft2(img)
    fshift = np.fft.fftshift(f)
    espectro_magnitud = 20 * np.log(np.abs(fshift) + 1)
    filas, columnas = img.shape
    centro_fila, centro_col = filas // 2, columnas // 2
    radio_ciego = 40
    espectro_magnitud[centro_fila-radio_ciego:centro_fila+radio_ciego,
                      centro_col-radio_ciego:centro_col+radio_ciego] = 0
    picos = np.sum(espectro_magnitud > UMBRAL_BRILLO)
    if picos > MAX_PICOS_PERMITIDOS:
        return False, f"FRAUDE FÍSICO: Ataque de pantalla detectado ({picos} picos Moiré)."
    else:
        return True, f"Soporte físico validado: Plástico real ({picos} picos)."
def detectar_photoshop_ela(ruta_imagen, umbral_anomalia=15):
    """
    Versión de PRODUCCIÓN del detector de Photoshop (ELA).
    Comprime la imagen y busca zonas que destaquen (pegotes digitales).
    """
    img_original = cv2.imread(ruta_imagen)
    if img_original is None:
        return False, "⚠️ Error: No se pudo leer la imagen.", None

    ruta_temp = "temp_ela_test.jpg"
    cv2.imwrite(ruta_temp, img_original, [cv2.IMWRITE_JPEG_QUALITY, 90])
    img_comprimida = cv2.imread(ruta_temp)
    diferencia = cv2.absdiff(img_original, img_comprimida)
    diferencia_gris = cv2.cvtColor(diferencia, cv2.COLOR_BGR2GRAY)
    mapa_calor = cv2.convertScaleAbs(diferencia_gris, alpha=15.0)
    if os.path.exists(ruta_temp):
        os.remove(ruta_temp)
    brillo_maximo = np.max(mapa_calor)
    brillo_medio = np.mean(mapa_calor)
    ratio_contraste = brillo_maximo / (brillo_medio + 1)
    if brillo_maximo > 200 and ratio_contraste > umbral_anomalia:
        veredicto = False
        mensaje = f"FRAUDE DIGITAL: Modificación con Photoshop detectada (Anomalía: {ratio_contraste:.1f})."
    else:
        veredicto = True
        mensaje = f"Imagen limpia: Sin manipulaciones digitales (Anomalía: {ratio_contraste:.1f})."

    return veredicto, mensaje, mapa_calor
def detectar_clonacion_sift(ruta_imagen):
    """
    PERITO 3: Detector de Copy-Move.
    Usa SIFT para buscar zonas de la imagen que sean matemáticamente idénticas.
    """
    img_bgr = cv2.imread(ruta_imagen)
    if img_bgr is None:
        return False, "Error: No se pudo leer la imagen.", None

    img_gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    sift = cv2.SIFT_create()
    keypoints, descriptores = sift.detectAndCompute(img_gray, None)
    if descriptores is None or len(descriptores) < 2:
        return True, "Imagen sin suficientes detalles para clonar.", None

    # 3. Comparamos el DNI consigo mismo
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(descriptores, descriptores, k=2)

    matches_clonados = []
    for m, n in matches:
        pt1 = np.array(keypoints[m.queryIdx].pt)
        pt2 = np.array(keypoints[n.trainIdx].pt)
        distancia_fisica = np.linalg.norm(pt1 - pt2)
        if n.distance < 50 and distancia_fisica > 40:
            matches_clonados.append(n)
    img_resultado = cv2.drawMatches(
        img_bgr, keypoints, img_bgr, keypoints, matches_clonados, None,
        flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS,
        matchColor=(0, 255, 0)
    )
    cantidad_clones = len(matches_clonados)
    if cantidad_clones > 10:
        return False, f"FRAUDE COPY-MOVE: Detectados {cantidad_clones} puntos clonados.", img_resultado
    else:
        return True, f"Geometría limpia: Sin rastro de tampón de clonar ({cantidad_clones} puntos aislados).", img_resultado
class MockBusterNet(nn.Module):
    def __init__(self):
        super(MockBusterNet, self).__init__()

    def forward(self, x):
        mascara_falsa = torch.zeros((1, 1, 256, 256))
        return None, mascara_falsa

def ia_clonacion_ejecutable(ruta_imagen):
    modelo = MockBusterNet()
    modelo.eval()
    img = cv2.imread(ruta_imagen)
    if img is None:
        return False, "Error: No encuentro la foto."

    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img_cuadrada = cv2.resize(img, (256, 256))
    transformacion = transforms.ToTensor()
    tensor_img = transformacion(img_cuadrada).unsqueeze(0)

    print(f"   -> Foto convertida a Tensor de tamaño: {tensor_img.shape}")
    with torch.no_grad():
        _, mascara_fraude = modelo(tensor_img)
    porcentaje_fraude = mascara_fraude.mean().item() * 100
    if porcentaje_fraude > 15.0:
        return False, f"IA DETECTA FRAUDE: ({porcentaje_fraude:.1f}% de la imagen alterada)."
    else:
        return True, f"IA aprueba: Textura original coherente (Nivel de anomalía: {porcentaje_fraude:.1f}%)."
