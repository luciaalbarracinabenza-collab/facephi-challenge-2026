# Rectificación por contorno, sejora de contraste, binarización
# Genera 2 imágenes: natural y binarizada, y luego se elige la mejor por MRZ

import cv2
import numpy as np
from doctr.io import DocumentFile
from doctr.models import ocr_predictor

def _ordenar_puntos(pts):
    rect = np.zeros((4,2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect

def rectificar_documento_contorno(img_bgr):
    """Devuelve (img_rectificada, ok). Si no detecta 4 esquinas bien, devuelve original."""
    original = img_bgr.copy()
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)

    # bordes
    edges = cv2.Canny(blur, 50, 150)

    contornos, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    contornos = sorted(contornos, key=cv2.contourArea, reverse=True)[:10]

    approx4 = None
    for c in contornos:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02 * peri, True)
        if len(approx) == 4:
            approx4 = approx.reshape(4,2)
            break

    if approx4 is None:
        return original, False

    rect = _ordenar_puntos(approx4)
    (tl, tr, br, bl) = rect

    widthA = np.linalg.norm(br - bl)
    widthB = np.linalg.norm(tr - tl)
    maxWidth = max(int(widthA), int(widthB))

    heightA = np.linalg.norm(tr - br)
    heightB = np.linalg.norm(tl - bl)
    maxHeight = max(int(heightA), int(heightB))

    # filtro de tamaños absurdos
    if maxWidth < 200 or maxHeight < 120:
        return original, False

    dst = np.array([
        [0, 0],
        [maxWidth - 1, 0],
        [maxWidth - 1, maxHeight - 1],
        [0, maxHeight - 1]
    ], dtype="float32")

    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(original, M, (maxWidth, maxHeight))
    return warped, True

def mejorar_contraste_gray(gray):
    """CLAHE suave para mejorar letras sin reventar fondo."""
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    return clahe.apply(gray)

def binarizacion_adaptativa_suave(gray):
    """Binarización adaptativa (opción 4) pero controlada.
    OJO: DocTR a veces va peor con binaria; por eso la probamos como variante."""
    # denoise leve
    g = cv2.GaussianBlur(gray, (3,3), 0)
    # adaptive threshold: si sale invertido, cambiar THRESH_BINARY por THRESH_BINARY_INV
    th = cv2.adaptiveThreshold(
        g, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31, 10
    )
    return th

def preprocesar_para_ocr(input_path, out_base="preproc", aplicar_binarizacion=False):
    img = cv2.imread(input_path)
    if img is None:
        raise FileNotFoundError(f"No puedo leer la imagen: {input_path}")
     # 1) Rectificar si se puede
    rect, ok_rect = rectificar_documento_contorno(img)

    # 2) Pasar a gray y mejorar contraste
    gray = cv2.cvtColor(rect, cv2.COLOR_BGR2GRAY)
    gray = mejorar_contraste_gray(gray)

    # Guardar versión natural
    out_natural = f"{out_base}_natural.jpg"
    cv2.imwrite(out_natural, gray)

    out_bin = None
    if aplicar_binarizacion:
        b = binarizacion_adaptativa_suave(gray)
        out_bin = f"{out_base}_bin.jpg"
        cv2.imwrite(out_bin, b)

    return {
        "rectificada": ok_rect,
        "natural_path": out_natural,
        "bin_path": out_bin
    }

def _score_best(best):
    if not best:
        return -10**9
    return best.get("score", -10**9)

import re

def _count_nif_like(line1: str):
    """Cuenta ocurrencias de patrón DNI típico (8 dígitos + letra) en línea 1."""
    if not line1:
        return 0
    return len(re.findall(r"\d{8}[A-Z]", line1))

def _max_digit_run(s: str):
    """Devuelve la longitud máxima de una racha de dígitos en s."""
    if not s:
        return 0
    runs = [len(m.group(0)) for m in re.finditer(r"\d+", s)]
    return max(runs) if runs else 0

def _quality_penalty(best):
    if not best:
        return 10**9

    lines = best.get("lines", [])
    if len(lines) < 1:
        return 10**9

    l1 = lines[0]

    pen = 0

    # 1. Penaliza en función de la racha de dígitos (más dígitos = peor)
    maxrun = _max_digit_run(l1)
    if maxrun > 8:
        pen += 50 + (maxrun - 8) * 80   # 9->130, 10->210, 11->290...

    # 2. Penaliza prefijo raro tipo IDESP + demasiadas letras seguidas (ruido OCR)
    if re.search(r"^IDESP[A-Z]{4,}", l1):
        pen += 60

    # 3. Si no hay ningún patrón NIF-like, penaliza un poco
    if _count_nif_like(l1) == 0:
        pen += 20

    return pen

def _n_issues(best):
    if not best:
        return 10**9
    return len(best.get("issues", []))

def elegir_mejor_procesado(best_nat, best_bin, result_nat, result_bin):
    """Evalúa la versión natural y la binarizada y devuelve la mejor candidata."""
    if best_nat and best_nat.get("ok") and not (best_bin and best_bin.get("ok")):
        return best_nat, result_nat, "NATURAL"
    elif best_bin and best_bin.get("ok") and not (best_nat and best_nat.get("ok")):
        return best_bin, result_bin, "BINARIZADA"
    elif best_nat and best_bin and best_nat.get("ok") and best_bin.get("ok"):
        if _score_best(best_bin) > _score_best(best_nat):
            return best_bin, result_bin, "BINARIZADA"
        else:
            return best_nat, result_nat, "NATURAL"
    else:
        # Lógica de penalización si ninguna valida
        pen_nat = _quality_penalty(best_nat)
        pen_bin = _quality_penalty(best_bin)
        if pen_bin >= pen_nat + 60:
            return best_nat, result_nat, "NATURAL"
        elif pen_nat >= pen_bin + 60:
            return best_bin, result_bin, "BINARIZADA"
        else:
            if _n_issues(best_bin) < _n_issues(best_nat):
                return best_bin, result_bin, "BINARIZADA"
            elif _n_issues(best_nat) < _n_issues(best_bin):
                return best_nat, result_nat, "NATURAL"
            else:
                if _score_best(best_bin) >= _score_best(best_nat) + 20:
                    return best_bin, result_bin, "BINARIZADA"
                else:
                    return best_nat, result_nat, "NATURAL"