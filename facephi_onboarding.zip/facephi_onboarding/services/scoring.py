# Scoring pro + calidad de lectura

# Pesos (calibrables)
W_MRZ = {
    "CHK_DOCNUM": 50,
    "CHK_BIRTH": 40,
    "CHK_EXPIRY": 40,
    "CHK_FINAL": 60,
}
W_TEMP = {
    "DOC_EXPIRED": 35,
    "DATE_BIRTH_INVALID": 25,
    "DATE_EXPIRY_INVALID": 25,
    "DATE_ORDER_INVALID": 30,
    "AGE_NEGATIVE": 30,
    "AGE_TOO_HIGH": 30,
}
W_FORENSICS = {
    "BIOMETRIC_MISMATCH": 150,
    "ANACHRONISM": 100,      
    "SCREEN_ATTACK": 90,     
    "COPY_MOVE_SIFT": 85,    
    "AI_CLONING": 70,        
    "PHOTOSHOP_ELA": 50,     
    "ENTROPY_MISMATCH": 40  
}

# Caps: hace el score estable
CAP_MRZ = 120
CAP_CROSS = 100
CAP_TEMP = 80
CAP_FORENSICS = 400

def score_mrz(best_candidate):
    score = 0
    reasons = []
    issues = best_candidate.get("issues", []) if best_candidate else []

    # 1. Diccionario para saber EXACTAMENTE dónde está el fallo
    UBICACION_FALLO = {
        "CHK_DOCNUM": "Dígito de Control del NÚMERO DE SOPORTE/DOCUMENTO",
        "CHK_BIRTH": "Dígito de Control de la FECHA DE NACIMIENTO",
        "CHK_EXPIRY": "Dígito de Control de la FECHA DE CADUCIDAD",
        "CHK_FINAL": "Dígito de Control GLOBAL (Último número de la línea 2)"
    }

    # Penalización base si no valida
    if best_candidate and not best_candidate.get("ok", False):
        score += 10
        # Mensaje más descriptivo
        reasons.append("❌ MRZ rechazada: Inconsistencias matemáticas detectadas.") 

    # Evitar doble conteo: si falla un campo base, CHK_FINAL puede ser redundante
    codes = [c for (c, _m) in issues]
    base_causes = {"CHK_DOCNUM", "CHK_BIRTH", "CHK_EXPIRY"}
    ignore_final = ("CHK_FINAL" in codes) and (len(base_causes.intersection(codes)) > 0)

    for code, msg in issues:
        if code == "CHK_FINAL" and ignore_final:
            continue
            
        score += W_MRZ.get(code, 20)
        
        # 2. Construimos el mensaje exacto
        lugar = UBICACION_FALLO.get(code, f"Campo desconocido ({code})")
        
        # Juntamos la ubicación exacta con el mensaje técnico que viene de tu otra función
        reasons.append(f"Fallo en {lugar} -> Detalle: {msg}")

    score = min(score, CAP_MRZ)
    return score, reasons

def score_cross(inconsistencies):
    incs = inconsistencies or []
    score = min(len(incs) * 25, CAP_CROSS)
    return score, incs

def score_temporal(temporal_issues):
    score = 0
    reasons = []
    for code, msg in (temporal_issues or []):
        score += W_TEMP.get(code, 20)
        reasons.append(msg)
    score = min(score, CAP_TEMP)
    return score, reasons

def score_forensics(forensic_results):
    score = 0
    reasons = []
    
    for key, result in forensic_results.items():
        if not result.get("passed", True):
            score += W_FORENSICS.get(key, 100)
            reasons.append(result.get("message", "Alerta forense detectada"))
            
    score = min(score, CAP_FORENSICS)
    return score, reasons

def fraud_level(total_score, best_candidate, inconsistencies, temporal_issues, forensic_reasons):
    # HIGH solo si hay múltiples señales o score alto de verdad
    if total_score == 0:
        return "LOW"

    issues = best_candidate.get("issues", []) if best_candidate else []
    n_issues = len(issues)

    # Si hay incoherencias cruzadas o temporal -> más serio
    if inconsistencies or temporal_issues or forensic_reasons:
        return "HIGH" if total_score >= 60 else "MEDIUM"

    # Si solo son checksums (típico OCR/specimen): MEDIUM salvo que haya muchos
    if n_issues <= 2 and total_score <= 80:
        return "MEDIUM"

    return "HIGH"

def readability_flags(best_candidate, temporal_issues, inconsistencies):
    """
    Flags de calidad / fiabilidad de lectura:
    - Si solo fallan checksums y todo lo demás cuadra -> OCR/MRZ uncertain
    - Si no hay MRZ -> unreadable
    """
    flags = []

    if best_candidate is None:
        flags.append("NO_MRZ_FOUND")
        return flags

    issues = best_candidate.get("issues", [])
    codes = [c for (c, _m) in issues]

    only_checksum = (len(codes) > 0) and all(c.startswith("CHK_") for c in codes)
    if only_checksum and (not temporal_issues) and (not inconsistencies):
        flags.append("CHECKSUM_MISMATCH_ONLY_POSSIBLE_OCR")

    if len(codes) >= 3:
        flags.append("MANY_MRZ_ERRORS_LOW_CONFIDENCE")

    return flags
    
def build_final_report(best, mrz_data, ocr_data, inconsistencies, temporal_issues,
                       scores, risk_level, quality_flags):
    return {
        "fraud_risk_level": risk_level,
        "quality_flags": quality_flags,

        "scores": scores,

        "mrz": {
            "lines": best["lines"],
            "valid_ok": best["ok"],
            "validation_issues": best["issues"],
            "fields": mrz_data,
        },

        "ocr": {
            "document_number": ocr_data.get("document_number"),
            "birth_date": ocr_data.get("birth_date"),
            "expiry_date": ocr_data.get("expiry_date"),
            "full_text_preview": (ocr_data.get("full_text", "")[:300] if isinstance(ocr_data.get("full_text", ""), str) else None),
        },

        "cross_validation": {
            "inconsistencies": inconsistencies
        },

        "temporal_logic": {
            "issues": temporal_issues
        }
    }
