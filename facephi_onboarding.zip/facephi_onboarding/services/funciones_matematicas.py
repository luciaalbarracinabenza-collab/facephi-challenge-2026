from datetime import date
import re
import unicodedata

# MRZ TD1 VALIDACIÓN
WEIGHTS = [7, 3, 1]

def char_value(c):
    if c.isdigit():
        return int(c)
    if c == "<":
        return 0
    return ord(c) - 55  # A=10, B=11...

def compute_check_digit(data):
    total = 0
    for i, c in enumerate(data):
        total += char_value(c) * WEIGHTS[i % 3]
    return str(total % 10)

def validate_td1(lines):
    issues = []
    l1, l2, l3 = lines

    # Documento
    doc_number = l1[5:14]
    doc_check = l1[14]
    if compute_check_digit(doc_number) != doc_check:
        issues.append(("CHK_DOCNUM",
                       f"Document number checksum mismatch: expected {compute_check_digit(doc_number)}, got {doc_check}"))

    # Fecha nacimiento
    birth = l2[0:6]
    birth_check = l2[6]
    if compute_check_digit(birth) != birth_check:
        issues.append(("CHK_BIRTH",
                       "Birth date checksum mismatch"))

    # Fecha caducidad
    expiry = l2[8:14]
    expiry_check = l2[14]
    if compute_check_digit(expiry) != expiry_check:
        issues.append(("CHK_EXPIRY",
                       "Expiry date checksum mismatch"))

    # Check final
    composite = (
        l1[5:30] +
        l2[0:7] +
        l2[8:15] +
        l2[18:29]
    )
    final_check = l2[29]
    if compute_check_digit(composite) != final_check:
        issues.append(("CHK_FINAL",
                       f"Final checksum mismatch: expected {compute_check_digit(composite)}, got {final_check}"))

    return {
        "ok": len(issues) == 0,
        "issues": issues
    }

def looks_like_yymmdd(s):
    if not (isinstance(s, str) and len(s) == 6 and s.isdigit()):
        return False
    if s in ("000000", "999999", "499999"):
        return False
    yy = int(s[0:2]); mm = int(s[2:4]); dd = int(s[4:6])
    if mm < 1 or mm > 12:
        return False
    if dd < 1 or dd > 31:
        return False
    return True

# Comparación MRZ y OCR
def normalize_name(s):
    if not s:
        return ""
    s = s.upper()
    s = unicodedata.normalize('NFD', s)
    s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    s = s.replace("Ñ", "N")
    s = re.sub(r"\s+", " ", s)
    return s.strip()

def compare_mrz_vs_ocr(mrz_data, ocr_data):
    inconsistencies = []
    if ocr_data["document_number"] and mrz_data["document_number"] not in ocr_data["document_number"]:
        inconsistencies.append("Número documento no coincide con OCR")

    mrz_name = normalize_name(mrz_data["name_line"])
    ocr_full = normalize_name(ocr_data["full_text"])
    mrz_words = [w for w in mrz_name.split() if len(w) >= 3]

    # Si ninguna palabra "fuerte" del MRZ aparece en todo el OCR, inconsistencia
    if mrz_words and not any(w in ocr_full for w in mrz_words):
        inconsistencies.append("Nombre no coincide con OCR")
    # Valicacion dni
    if ocr_data["document_number"]:
        print(ocr_data["document_number"])
        letra_leida = ocr_data["document_number"][-1] # Saca la última letra
        print(letra_leida)
        nif_ok, msg = validar_letra_nif_cruzada(mrz_data["document_number"], letra_leida)
        if not nif_ok:
            inconsistencies.append(msg)
    #valudacion idesp
    if ocr_data["idesp_frontal"]:
        idesp_ok, msg_idesp = validar_soporte_idesp(mrz_data["idesp"], ocr_data["idesp_frontal"])
        if not idesp_ok:
            inconsistencies.append(msg_idesp)


    return inconsistencies

def validar_letra_nif_cruzada(mrz_num_doc, ocr_letra_frontal):
    """
    Cruza el número de la MRZ con la letra leída por OCR en el frontal.
    """
    letras_validas = "TRWAGMYFPDXBNJZSQVHLCKE"
    solo_numeros = "".join(filter(str.isdigit, mrz_num_doc))

    if not solo_numeros:
        return False, "No se encontraron números en el campo MRZ"
    if len(solo_numeros) < 7:
        return False, f"Error de lectura OCR: Imposible validar. Solo se leyeron {len(solo_numeros)} números de la MRZ ({solo_numeros})."
    print(len(solo_numeros))
    dni_int = int(solo_numeros)
    print(dni_int % 23)
    letra_teorica = letras_validas[dni_int % 23]
    print(letra_teorica)
    letra_ocr = ocr_letra_frontal.strip().upper()
    if letra_teorica == letra_ocr:
        return True, f"Validación NIF correcta: {letra_teorica}"
    else:
        return False, f"Fraude detectado: La letra frontal es {letra_ocr} pero debería ser {letra_teorica}"

def validar_soporte_idesp(idesp_mrz, ocr_soporte_frontal):
    """
    Compara el número de soporte extraído de la MRZ con el leído en el frontal.
    """
    idesp_frontal = ocr_soporte_frontal.replace(" ", "").strip().upper()
    print(idesp_frontal)
    print(idesp_mrz)
    if idesp_mrz == idesp_frontal:
        return True, f"Soporte IDESP verificado: {idesp_mrz}"
    else:
        return False, f"Alerta de seguridad: El soporte frontal ({idesp_frontal}) no coincide con la MRZ ({idesp_mrz})"
    
# Fechas robustas + validaciones temporales
def yymmdd_candidates(yymmdd: str):
    """Devuelve posibles fechas para YYMMDD probando 1900 y 2000."""
    if not yymmdd or len(yymmdd) != 6 or not yymmdd.isdigit():
        return []
    yy = int(yymmdd[0:2]); mm = int(yymmdd[2:4]); dd = int(yymmdd[4:6])

    cands = []
    for century in (1900, 2000):
        try:
            cands.append(date(century + yy, mm, dd))
        except ValueError:
            pass
    return cands

def parse_birth_date(yymmdd: str):
    """Elige el siglo que produzca una edad razonable (0..120)."""
    today = date.today()
    cands = yymmdd_candidates(yymmdd)
    if not cands:
        return None

    best = None
    best_pen = 10**9
    for d in cands:
        age = (today - d).days / 365.25
        pen = 0
        if age < 0: pen += 1000
        if age > 120: pen += 1000
        pen += abs(age - 35)  # preferencia suave
        if pen < best_pen:
            best_pen = pen
            best = d
    return best

def parse_expiry_date(yymmdd: str, birth_date: date | None):
    """
    Caducidad: elige el siglo que haga la fecha:
    - posterior al nacimiento (si existe)
    - y razonable respecto al presente (no 1931 si el nacimiento es 1980)
    """
    today = date.today()
    cands = yymmdd_candidates(yymmdd)
    if not cands:
        return None

    best = None
    best_pen = 10**9
    for d in cands:
        pen = 0

        if birth_date and d <= birth_date:
            pen += 2000  # muy malo

        # Ventana razonable: [hoy-20 años, hoy+30 años]
        if d < date(today.year - 20, 1, 1): pen += 500
        if d > date(today.year + 30, 12, 31): pen += 500

        # preferencia: cerca de hoy / futuro cercano
        pen += abs((d - today).days) / 365.25

        if pen < best_pen:
            best_pen = pen
            best = d

    return best

def temporal_logic_checks(mrz_data):
    """
    mrz_data: dict con 'birth_date' y 'expiry_date' en YYMMDD.
    Devuelve lista de (code, msg).
    """
    issues = []
    today = date.today()

    b = parse_birth_date(mrz_data.get("birth_date"))
    e = parse_expiry_date(mrz_data.get("expiry_date"), b)

    if b is None:
        issues.append(("DATE_BIRTH_INVALID", "Fecha de nacimiento inválida o ilegible"))
    if e is None:
        issues.append(("DATE_EXPIRY_INVALID", "Fecha de caducidad inválida o ilegible"))

    if b and e:
        if b >= e:
            issues.append(("DATE_ORDER_INVALID", "Nacimiento debe ser anterior a caducidad"))

        age = (today - b).days / 365.25
        if age < 0:
            issues.append(("AGE_NEGATIVE", "Fecha de nacimiento en el futuro"))
        elif age > 120:
            issues.append(("AGE_TOO_HIGH", f"Edad no razonable: {age:.1f} años"))

    if e and e < today:
        issues.append(("DOC_EXPIRED", "Documento caducado (expiry_date < hoy)"))

    return issues

def validar_anacronismo_dni4(fecha_caducidad_mrz, fecha_nacimiento_mrz):
    """
    Comprueba si las fechas del DNI 4.0 tienen sentido matemático,
    sabiendo que se lanzó en 2021 y estamos en 2026.
    """
    anio_actual = 2026
    anio_lanzamiento_dni4 = 2021

    if fecha_caducidad_mrz in ("999999", "000000"):
        return True, "DNI Permanente. Validación temporal omitida."

    try:
        yy_nac = int(fecha_nacimiento_mrz[0:2])
        yy_cad = int(fecha_caducidad_mrz[0:2])
    except:
        return False, "Error leyendo las fechas de la MRZ."

    anio_nac = 1900 + yy_nac if yy_nac > 26 else 2000 + yy_nac
    anio_cad = 2000 + yy_cad

    edad_al_caducar = anio_cad - anio_nac

    if edad_al_caducar <= 7:
        validez = 2
    elif edad_al_caducar <= 35:
        validez = 5
    else:
        validez = 10

    anio_emision = anio_cad - validez

    if anio_emision > anio_actual:
        return False, f"FRAUDE LÓGICO: Fecha de emisión en el futuro ({anio_emision})."

    if anio_emision < anio_lanzamiento_dni4:
        return False, f"FRAUDE ANACRÓNICO: El DNI 4.0 salió en 2021, pero este se emitió en {anio_emision}."

    return True, f"Temporalidad correcta: DNI 4.0 emitido en {anio_emision}."
def validar_entropia_ocr(confianza_media_frontal, confianza_media_mrz):
    """
    Compara los niveles de confianza (ruido/entropía) del OCR entre el frontal y la MRZ.
    Detecta inyecciones digitales si un lado es "demasiado perfecto" respecto al otro.
    """
    UMBRAL_DIFERENCIA = 0.12
    diferencia = abs(confianza_media_frontal - confianza_media_mrz)
    if diferencia > UMBRAL_DIFERENCIA:
        return False, f"FRAUDE DE INYECCIÓN: Desfase de ruido del {(diferencia*100):.1f}%. Frontal ({(confianza_media_frontal*100):.1f}%) vs MRZ ({(confianza_media_mrz*100):.1f}%)."
    if confianza_media_mrz > 0.985 and confianza_media_frontal < 0.90:
        return False, f"FRAUDE DIGITAL: MRZ artificialmente perfecta ({(confianza_media_mrz*100):.1f}%) pegada sobre un frontal desgastado ({(confianza_media_frontal*100):.1f}%)."
    return True,f"Entropía natural. Desgaste visual coherente (Diferencia del {(diferencia*100):.1f}%)."
    