from pydantic import BaseModel
from typing import List, Optional

class DNIRequest(BaseModel):
    image_base64: str
    extracted_nif: Optional[str] = None

class ValidationDetails(BaseModel):
    mrz_checksum_valid: bool
    nif_module_23_valid: bool
    idesp_match: bool

class FraudScores(BaseModel):
    ela_score: float
    moire_detected: bool
    entropy_manipulation: bool

class RiskAssessment(BaseModel):
    level: str
    total_score: float
    justification: List[str]

class DNIResponse(BaseModel):
    document_type: str
    validations: ValidationDetails
    fraud_scores: FraudScores
    risk_assessment: RiskAssessment