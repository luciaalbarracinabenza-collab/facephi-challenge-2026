import base64
import os
import uuid
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from doctr.io import DocumentFile
from doctr.models import ocr_predictor
from services import preprocesamiento, vision, funciones_matematicas, detector_fraude, scoring

app = FastAPI(
    title="FacePhi DNI Orchestrator",
    description="Motor de inteligencia documental y scoring antifraude orquestado para n8n.",
    version="2.0.0"
)
print("Cargando modelo DocTR...")
ocr_model = ocr_predictor(pretrained=True)
print("¡Modelo cargado y listo para producción!")
class DNIRequest(BaseModel):
    front_image_base64: str
    back_image_base64: str
    selfie_image_base64: str


@app.post("/api/v1/fraud/analyze")
async def analyze_document(request: DNIRequest):
    request_id = str(uuid.uuid4())[:8]
    temp_front = f"temp_front_{request_id}.jpg"
    temp_back = f"temp_back_{request_id}.jpg"
    temp_selfie = f"temp_selfie_{request_id}.jpg"
    
    try:
        with open(temp_front, "wb") as f:
            f.write(base64.b64decode(request.front_image_base64.split(",")[-1]))
        with open(temp_back, "wb") as f:
            f.write(base64.b64decode(request.back_image_base64.split(",")[-1]))
        with open(temp_selfie, "wb") as f: # <--- NUEVO
            f.write(base64.b64decode(request.selfie_image_base64.split(",")[-1]))
        #datos_limpios_back = preprocesamiento.preprocesar_para_ocr(temp_back, "clean_back")
        # Ahora leemos la foto LIMPIA, no la sucia
        #doc_back = DocumentFile.from_images(datos_limpios_back["natural_path"]) 
        doc_back = DocumentFile.from_images(temp_back) 
        res_back = ocr_model(doc_back)
        best_mrz = vision.extract_best_td1_from_doctr(res_back)
        if not best_mrz:
            raise ValueError("No se detectó ninguna MRZ válida en la parte trasera.")
        doc_front = DocumentFile.from_images(temp_front)
        res_front = ocr_model(doc_front)
        
        info_mapa, mensaje_mapa = vision.selector_mapa(best_mrz["lines"])
            
        if info_mapa is None:
                raise ValueError(f"Fallo en la lectura del documento: {mensaje_mapa}")
                
        formato_detectado = info_mapa["formato"]
        pais_detectado = info_mapa["pais"]
        mrz_data = vision.extractor_mrz_universal(
                best_mrz["lines"], 
                formato=formato_detectado, 
                pais=pais_detectado
        )
        ocr_data = vision.extract_fields_from_ocr(res_front)
        inconsistencies = funciones_matematicas.compare_mrz_vs_ocr(mrz_data, ocr_data)
        temporal_issues = funciones_matematicas.temporal_logic_checks(mrz_data)
        ok_anacronismo, msg_anacronismo = funciones_matematicas.validar_anacronismo_dni4(
            mrz_data.get("expiry_date", ""), 
            mrz_data.get("birth_date", "")
        )
        entropia_front = vision.calcular_entropia_doctr(res_front)
        entropia_back = vision.calcular_entropia_doctr(res_back) if res_back else 0.0
        ok_entropia, msg_entropia = funciones_matematicas.validar_entropia_ocr(entropia_front, entropia_back)
        ok_ela, msg_ela, _ = detector_fraude.detectar_photoshop_ela(temp_front)
        ok_sift, msg_sift, _ = detector_fraude.detectar_clonacion_sift(temp_front)
        ok_pantalla, msg_pantalla = detector_fraude.detectar_ataque_pantalla(temp_front)
        ok_ia, msg_ia = detector_fraude.ia_clonacion_ejecutable(temp_front)
        ok_bio, msg_bio = detector_fraude.validar_biometria_facial(temp_front, temp_selfie)
        forensic_results = {
            "PHOTOSHOP_ELA": {"passed": ok_ela, "message": msg_ela},
            "COPY_MOVE_SIFT": {"passed": ok_sift, "message": msg_sift},
            "SCREEN_ATTACK": {"passed": ok_pantalla, "message": msg_pantalla},
            "AI_CLONING": {"passed": ok_ia, "message": msg_ia},
            "ENTROPY_MISMATCH": {"passed": ok_entropia, "message": msg_entropia},
            "ANACHRONISM": {"passed": ok_anacronismo, "message": msg_anacronismo},
            "BIOMETRIC_MISMATCH": {"passed": ok_bio, "message": msg_bio}
        }
        s_mrz,reasons= scoring.score_mrz(best_mrz)
        print(s_mrz)
        print(reasons)
        s_cross, _ = scoring.score_cross(inconsistencies)
        s_temp, _ = scoring.score_temporal(temporal_issues)
        s_forensics, forensic_reasons = scoring.score_forensics(forensic_results)
        total_score = s_mrz + s_cross + s_temp +s_forensics

        risk_level = scoring.fraud_level(total_score, best_mrz, inconsistencies, temporal_issues, forensic_reasons)
        flags = scoring.readability_flags(best_mrz, temporal_issues, inconsistencies)
        scores_dict = {"mrz": s_mrz, "cross_validation": s_cross, "temporal_logic": s_temp,"forensics": s_forensics, "total": total_score}
        reporte_final = scoring.build_final_report(
            best_mrz, mrz_data, ocr_data, inconsistencies, temporal_issues,
            scores_dict, risk_level, flags
        )
        reporte_final["digital_forensics"] = {
            "photoshop_ela": {"passed": ok_ela, "message": msg_ela},
            "copy_move_sift": {"passed": ok_sift, "message": msg_sift}
        }

        return reporte_final

    finally:
        for p in [temp_front, temp_back,temp_selfie]:
            if p and os.path.exists(p):
                os.remove(p)
        